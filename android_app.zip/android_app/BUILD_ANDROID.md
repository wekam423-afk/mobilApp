# بناء تطبيق أندرويد المستقل — الإخلاص بلاست

التطبيق يعمل **Offline-First** على الموبايل (IndexedDB محلي)، ويُزامن مع **Supabase** عند توفر الإنترنت — بدون الحاجة لنفس شبكة الواي فاي مع اللابتوب.

## 1) إعداد السحابة (مرة واحدة)

1. أنشئ مشروع مجاني على [Supabase](https://supabase.com).
2. من SQL Editor نفّذ ملف المشروع: `../supabase_schema.sql`.
3. انسخ **Project URL** و **anon public key**.
4. على اللابتوب: انسخ `sync_config.example.json` إلى `sync_config.json` بجانب `pos_inventory.db` واملأ البيانات وضع `"enabled": true`.
5. من البرنامج أو API:
   - `POST /api/sync/bootstrap` لرفع البيانات الحالية.
   - أو انتظر المزامنة التلقائية بعد أي بيع/تعديل سعر.

## 2) بناء APK (Capacitor)

متطلبات: Node.js 18+ و Android Studio.

```bat
cd android_app
npm install
npm run build:www
npx cap add android
npx cap sync android
npx cap open android
```

من Android Studio: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

أو استخدم الملف: `بناء_اندرويد.bat` من جذر المشروع.

## 3) استخدام التطبيق

1. افتح التطبيق على الموبايل.
2. أدخل نفس رابط Supabase و Anon Key.
3. سجّل المبيعات بدون نت — تُحفظ محلياً.
4. عند عودة النت تتزامن تلقائياً مع اللابتوب عبر السحابة.

## ملاحظات

- الأسعار مركزية (جدول المنتجات في السحابة).
- كميات كل جهاز/فرع تُزامَن عبر `pos_branch_inventory`.
- التطبيق حقيقي (WebView أصلي عبر Capacitor) وليس مجرد تبويب متصفح.
