let cart = [];

function money(n) {
  return Number(n || 0).toLocaleString("en-EG", { maximumFractionDigits: 2 }) + " ج.م";
}

function showPanel(name, btn) {
  document.querySelectorAll(".panel").forEach(p => p.classList.remove("active"));
  document.getElementById("panel-" + name).classList.add("active");
  document.querySelectorAll(".nav-bottom button").forEach(b => b.classList.remove("active"));
  if (btn) btn.classList.add("active");
}

function openSetup() {
  document.getElementById("appScreen").style.display = "none";
  document.getElementById("setupScreen").style.display = "";
  const cfg = CloudSync.loadConfig();
  document.getElementById("cfgUrl").value = cfg.supabase_url || "";
  document.getElementById("cfgKey").value = cfg.supabase_anon_key || "";
  document.getElementById("cfgName").value = cfg.device_name || "موبايل فرع";
  document.getElementById("cfgEnabled").checked = cfg.enabled !== false;
}

function saveSetup() {
  const cfg = CloudSync.loadConfig();
  cfg.supabase_url = document.getElementById("cfgUrl").value.trim();
  cfg.supabase_anon_key = document.getElementById("cfgKey").value.trim();
  cfg.device_name = document.getElementById("cfgName").value.trim() || "موبايل";
  cfg.enabled = document.getElementById("cfgEnabled").checked;
  if (!cfg.device_id) cfg.device_id = OfflineStore.uuid();
  CloudSync.saveConfig(cfg);
  enterApp();
}

async function enterApp() {
  document.getElementById("setupScreen").style.display = "none";
  document.getElementById("appScreen").style.display = "";
  await OfflineStore.openDb();
  CloudSync.startAutoSync(CloudSync.loadConfig().sync_interval_seconds || 45);
  await refreshAll();
}

async function updateSyncBadge() {
  const online = await CloudSync.isOnline();
  const pending = (await OfflineStore.pendingQueue()).length;
  const last = await OfflineStore.getMeta("last_sync_at", "—");
  const el = document.getElementById("syncBadge");
  if (!CloudSync.loadConfig().enabled) el.textContent = "سحابة متوقفة — محلي فقط";
  else if (!online) el.textContent = "بدون نت — Offline (" + pending + " بانتظار الرفع)";
  else el.textContent = "متصل — معلّق: " + pending + " | آخر مزامنة: " + String(last).slice(11, 19);
}

async function refreshAll() {
  await updateSyncBadge();
  const invoices = await OfflineStore.getAll("invoices");
  const products = (await OfflineStore.getAll("products")).filter(p => !p.deleted);
  const today = new Date().toISOString().slice(0, 10);
  const todayInvs = invoices.filter(i => String(i.created_at || "").startsWith(today) && !i.deleted);
  const sales = todayInvs.reduce((s, i) => s + Number(i.net_amount || 0), 0);
  document.getElementById("kpiSales").textContent = money(sales);
  document.getElementById("kpiCount").textContent = todayInvs.length;
  document.getElementById("kpiProducts").textContent = products.length;
  renderSaleProducts();
  renderPrices();
  renderCart();
}

let productByUuid = {};

async function renderSaleProducts() {
  const q = (document.getElementById("saleSearch").value || "").trim().toLowerCase();
  const products = (await OfflineStore.getAll("products")).filter(p => !p.deleted);
  productByUuid = {};
  products.forEach(p => { productByUuid[p.uuid] = p; });
  const list = products.filter(p => !q || (p.name || "").toLowerCase().includes(q) || (p.barcode || "").includes(q));
  document.getElementById("saleProducts").innerHTML = list.slice(0, 40).map(p => `
    <div class="card row-flex">
      <div>
        <div style="font-weight:800">${escapeHtml(p.name)}</div>
        <div class="muted">${escapeHtml(p.barcode || "")}</div>
      </div>
      <div style="text-align:left">
        <div class="price">${money(p.selling_price)}</div>
        <button class="btn btn-primary" style="width:auto;min-height:36px;margin:0" onclick="addToCart('${p.uuid}')">+</button>
      </div>
    </div>
  `).join("") || `<div class="muted" style="padding:20px;text-align:center">لا توجد منتجات بعد — فعّل المزامنة لسحب الأسعار من الجهاز الرئيسي</div>`;
}

function escapeHtml(s) {
  return String(s || "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function addToCart(uuid) {
  const p = productByUuid[uuid];
  if (!p) return;
  const ex = cart.find(x => x.product_uuid === p.uuid);
  if (ex) ex.quantity += 1;
  else cart.push({
    product_uuid: p.uuid,
    product_id: p.id,
    name: p.name,
    unit_price: Number(p.selling_price || 0),
    cost_price: Number(p.cost_price || 0),
    quantity: 1
  });
  renderCart();
}

function renderCart() {
  const total = cart.reduce((s, i) => s + i.unit_price * i.quantity, 0);
  document.getElementById("cartTotal").textContent = money(total);
  document.getElementById("cartBox").innerHTML = cart.length
    ? cart.map(i => `${i.name} × ${i.quantity} = ${money(i.unit_price * i.quantity)}`).join("<br>")
    : "فارغة";
}

async function checkoutLocal() {
  if (!cart.length) return alert("السلة فارغة");
  const net = cart.reduce((s, i) => s + i.unit_price * i.quantity, 0);
  const inv = {
    uuid: OfflineStore.uuid(),
    invoice_number: "M-" + Date.now(),
    customer_name: document.getElementById("saleCustomer").value.trim() || null,
    payment_type: "cash",
    total_amount: net,
    discount: 0,
    net_amount: net,
    paid_amount: net,
    remaining_amount: 0,
    created_at: OfflineStore.nowIso(),
    updated_at: OfflineStore.nowIso(),
    deleted: 0,
    device_id: (CloudSync.loadConfig().device_id || "android")
  };
  await OfflineStore.upsertLocal("invoices", inv, true);
  for (const line of cart) {
    await OfflineStore.upsertLocal("invoice_items", {
      uuid: OfflineStore.uuid(),
      invoice_uuid: inv.uuid,
      invoice_id: inv.id,
      product_id: line.product_id,
      product_name: line.name,
      unit_price: line.unit_price,
      cost_price: line.cost_price,
      quantity: line.quantity,
      subtotal: line.unit_price * line.quantity,
      updated_at: OfflineStore.nowIso(),
      deleted: 0
    }, true);
  }
  cart = [];
  document.getElementById("saleCustomer").value = "";
  renderCart();
  alert("تم حفظ الفاتورة محلياً. ستُرفع للسحابة عند توفر الإنترنت.");
  CloudSync.syncOnce().then(refreshAll);
  refreshAll();
}

async function renderPrices() {
  const q = (document.getElementById("priceSearch").value || "").trim().toLowerCase();
  const products = (await OfflineStore.getAll("products")).filter(p => !p.deleted);
  const list = products.filter(p => !q || (p.name || "").toLowerCase().includes(q) || (p.barcode || "").includes(q));
  document.getElementById("priceBox").innerHTML = list.map(p => `
    <div class="card row-flex">
      <div>
        <div style="font-weight:800">${p.name}</div>
        <div class="muted">سعر موحّد من السحابة</div>
      </div>
      <div class="price">${money(p.selling_price)}</div>
    </div>
  `).join("") || `<div class="muted" style="text-align:center;padding:24px">لا توجد أسعار بعد</div>`;
}

(async function boot() {
  await OfflineStore.openDb();
  const cfg = CloudSync.loadConfig();
  if (cfg.supabase_url && cfg.supabase_anon_key) enterApp();
  else openSetup();
  window.addEventListener("online", () => CloudSync.syncOnce().then(refreshAll));
})();
