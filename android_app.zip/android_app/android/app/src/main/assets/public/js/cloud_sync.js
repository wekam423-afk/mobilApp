/**
 * مزامنة سحابية مع Supabase REST من تطبيق الموبايل.
 */
(function (global) {
  const CFG_KEY = "supabase_config";

  function loadConfig() {
    try {
      return JSON.parse(localStorage.getItem(CFG_KEY) || "{}");
    } catch (e) {
      return {};
    }
  }

  function saveConfig(cfg) {
    localStorage.setItem(CFG_KEY, JSON.stringify(cfg || {}));
  }

  async function isOnline() {
    if (global.Capacitor && global.Capacitor.Plugins && global.Capacitor.Plugins.Network) {
      try {
        const st = await global.Capacitor.Plugins.Network.getStatus();
        return !!st.connected;
      } catch (e) {}
    }
    return navigator.onLine;
  }

  async function rest(cfg, method, table, query, body) {
    const base = (cfg.supabase_url || "").replace(/\/$/, "");
    const key = cfg.supabase_anon_key || "";
    if (!base || !key) throw new Error("إعدادات السحابة غير مكتملة");
    const url = `${base}/rest/v1/${table}${query || ""}`;
    const headers = {
      apikey: key,
      Authorization: "Bearer " + key,
      "Content-Type": "application/json",
      Prefer: method === "GET" ? "return=representation" : "resolution=merge-duplicates,return=minimal"
    };
    const res = await fetch(url, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined
    });
    if (!res.ok) {
      const t = await res.text();
      throw new Error(t || ("HTTP " + res.status));
    }
    const text = await res.text();
    return text ? JSON.parse(text) : [];
  }

  const STORE_MAP = {
    products: "pos_products",
    inventory: "pos_branch_inventory",
    branch_inventory: "pos_branch_inventory",
    invoices: "pos_invoices",
    invoice_items: "pos_invoice_items",
    branches: "pos_branches",
    customers: "pos_customers"
  };

  async function pushPending(cfg) {
    const pending = await OfflineStore.pendingQueue();
    let n = 0;
    for (const item of pending) {
      const cloud = STORE_MAP[item.table_name] || STORE_MAP[item.payload && item.table];
      if (!cloud) continue;
      const payload = Object.assign({}, item.payload, {
        device_id: cfg.device_id || "android",
        updated_at: item.payload.updated_at || OfflineStore.nowIso()
      });
      try {
        if (item.operation === "delete") {
          await rest(cfg, "DELETE", cloud, "?uuid=eq." + encodeURIComponent(payload.uuid));
        } else {
          await rest(cfg, "POST", cloud, "", [payload]);
        }
        await OfflineStore.markSynced(item.uuid);
        n++;
      } catch (e) {
        console.warn("push fail", e);
      }
    }
    return n;
  }

  async function pullTable(cfg, localStore, cloudTable, since) {
    const q = `?select=*&updated_at=gt.${encodeURIComponent(since)}&order=updated_at.asc&limit=500`;
    let rows = [];
    try {
      rows = await rest(cfg, "GET", cloudTable, q);
    } catch (e) {
      return since;
    }
    let maxTs = since;
    for (const remote of rows || []) {
      if (!remote.uuid) continue;
      const local = await OfflineStore.get(localStore, remote.uuid);
      const rts = String(remote.updated_at || "");
      const lts = local ? String(local.updated_at || "") : "";
      if (local && lts && rts && lts >= rts) continue;
      if (Number(remote.deleted || 0) === 1) continue;
      await OfflineStore.put(localStore, remote);
      if (rts > maxTs) maxTs = rts;
    }
    return maxTs;
  }

  async function syncOnce() {
    const cfg = loadConfig();
    if (!cfg.enabled) return { ok: false, message: "المزامنة غير مفعّلة" };
    if (!(await isOnline())) return { ok: false, offline: true, message: "بدون إنترنت — العمل محلي" };
    if (!cfg.device_id) {
      cfg.device_id = OfflineStore.uuid();
      saveConfig(cfg);
    }
    const pushed = await pushPending(cfg);
    let since = (await OfflineStore.getMeta("last_pull_at", "1970-01-01T00:00:00Z"));
    since = await pullTable(cfg, "products", "pos_products", since);
    since = await pullTable(cfg, "inventory", "pos_branch_inventory", since);
    since = await pullTable(cfg, "invoices", "pos_invoices", since);
    since = await pullTable(cfg, "invoice_items", "pos_invoice_items", since);
    since = await pullTable(cfg, "branches", "pos_branches", since);
    since = await pullTable(cfg, "customers", "pos_customers", since);
    await OfflineStore.setMeta("last_pull_at", since);
    await OfflineStore.setMeta("last_sync_at", OfflineStore.nowIso());
    return { ok: true, pushed, since };
  }

  let timer = null;
  function startAutoSync(seconds) {
    stopAutoSync();
    const sec = Math.max(20, seconds || 45);
    timer = setInterval(() => { syncOnce().catch(() => {}); }, sec * 1000);
    syncOnce().catch(() => {});
  }

  function stopAutoSync() {
    if (timer) clearInterval(timer);
    timer = null;
  }

  global.CloudSync = { loadConfig, saveConfig, isOnline, syncOnce, startAutoSync, stopAutoSync };
})(window);
