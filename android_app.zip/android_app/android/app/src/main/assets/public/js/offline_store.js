/**
 * قاعدة بيانات محلية Offline-First للموبايل (IndexedDB).
 * تعمل بدون إنترنت بالكامل، وتُزامَن مع Supabase عند توفر الشبكة.
 */
(function (global) {
  const DB_NAME = "ikhlas_pos_mobile";
  const DB_VER = 1;
  let dbPromise = null;

  function openDb() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VER);
      req.onupgradeneeded = () => {
        const db = req.result;
        for (const store of [
          "products", "inventory", "invoices", "invoice_items",
          "branches", "customers", "sync_queue", "meta"
        ]) {
          if (!db.objectStoreNames.contains(store)) {
            const os = db.createObjectStore(store, { keyPath: "uuid" });
            if (store !== "meta" && store !== "sync_queue") {
              try { os.createIndex("updated_at", "updated_at", { unique: false }); } catch (e) {}
            }
            if (store === "sync_queue") {
              try { os.createIndex("synced", "synced", { unique: false }); } catch (e) {}
            }
          }
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    return dbPromise;
  }

  function txDone(tx) {
    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error);
    });
  }

  async function put(store, value) {
    const db = await openDb();
    const tx = db.transaction(store, "readwrite");
    tx.objectStore(store).put(value);
    await txDone(tx);
  }

  async function getAll(store) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(store, "readonly");
      const req = tx.objectStore(store).getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  }

  async function get(store, uuid) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(store, "readonly");
      const req = tx.objectStore(store).get(uuid);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  }

  async function setMeta(key, value) {
    await put("meta", { uuid: key, value });
  }

  async function getMeta(key, fallback) {
    const row = await get("meta", key);
    return row ? row.value : fallback;
  }

  function uuid() {
    if (crypto.randomUUID) return crypto.randomUUID();
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, c => {
      const r = (Math.random() * 16) | 0;
      return (c === "x" ? r : (r & 0x3) | 0x8).toString(16);
    });
  }

  function nowIso() {
    return new Date().toISOString();
  }

  async function enqueue(table, record, operation) {
    const item = {
      uuid: uuid(),
      table_name: table,
      record_uuid: record.uuid,
      operation: operation || "upsert",
      payload: record,
      created_at: nowIso(),
      synced: 0
    };
    await put("sync_queue", item);
  }

  async function upsertLocal(store, record, queueSync) {
    if (!record.uuid) record.uuid = uuid();
    record.updated_at = nowIso();
    record.deleted = record.deleted || 0;
    await put(store, record);
    if (queueSync !== false) await enqueue(store === "inventory" ? "branch_inventory" : store, record, "upsert");
    return record;
  }

  async function pendingQueue() {
    const all = await getAll("sync_queue");
    return all.filter(x => !x.synced);
  }

  async function markSynced(queueUuid) {
    const row = await get("sync_queue", queueUuid);
    if (!row) return;
    row.synced = 1;
    await put("sync_queue", row);
  }

  global.OfflineStore = {
    openDb, put, get, getAll, setMeta, getMeta, uuid, nowIso,
    enqueue, upsertLocal, pendingQueue, markSynced
  };
})(window);
