package com.ikhlas.plast.pos;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
