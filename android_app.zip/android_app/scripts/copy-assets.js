const fs = require("fs");
const path = require("path");

const root = path.join(__dirname, "..");
const www = path.join(root, "www");
const iconsSrc = path.join(root, "..", "static", "icons");
const iconsDst = path.join(www, "icons");

fs.mkdirSync(iconsDst, { recursive: true });
for (const name of ["icon-192.png", "icon-512.png", "apple-touch-icon.png", "maskable-512.png"]) {
  const src = path.join(iconsSrc, name);
  if (fs.existsSync(src)) fs.copyFileSync(src, path.join(iconsDst, name));
}
console.log("Assets ready in", www);
